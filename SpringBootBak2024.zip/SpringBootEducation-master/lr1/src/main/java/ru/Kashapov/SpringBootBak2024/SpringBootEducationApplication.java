package ru.Kashapov.SpringBootBak2024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEducationApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootEducationApplication.class, args);
    }

}