package ru.Kashapov.SpringBootBak2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEducationApplicationTests {

	@Test
	void contextLoads() {
	}

}
