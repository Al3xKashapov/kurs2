package ru.Kashapov.SpringBootBak2024.exception;

public class ValidationFailedException extends Exception {
    public ValidationFailedException(String message) { super(message); }
}
