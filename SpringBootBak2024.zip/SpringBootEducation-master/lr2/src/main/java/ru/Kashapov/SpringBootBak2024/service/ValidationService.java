package ru.Kashapov.SpringBootBak2024.service;

import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import ru.Kashapov.SpringBootBak2024.model.Request;
import ru.Kashapov.SpringBootBak2024.exception.ValidationFailedException;


@Service
public interface ValidationService {
    void isValid(BindingResult bindingResult) throws ValidationFailedException;
    void isValidRequest(Request request) throws ValidationFailedException;
}
