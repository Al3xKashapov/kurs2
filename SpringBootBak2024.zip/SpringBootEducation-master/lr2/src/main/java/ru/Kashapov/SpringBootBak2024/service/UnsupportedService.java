package ru.Kashapov.SpringBootBak2024.service;

import org.springframework.stereotype.Service;
import ru.Kashapov.SpringBootBak2024.exception.UnsupportedCodeException;

@Service
public interface UnsupportedService {
    void isSupportCode(String code) throws UnsupportedCodeException;
}
