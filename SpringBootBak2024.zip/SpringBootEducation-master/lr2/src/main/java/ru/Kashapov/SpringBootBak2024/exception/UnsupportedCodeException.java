package ru.Kashapov.SpringBootBak2024.exception;

public class UnsupportedCodeException extends Exception {
    public UnsupportedCodeException(String message) { super(message); }
}