package ru.Kashapov.SpringBootBak2024.service;

import org.springframework.stereotype.Service;
import ru.Kashapov.SpringBootBak2024.model.Response;

@Service
public interface ModifyResponseService {

    Response modify(Response response);
}
