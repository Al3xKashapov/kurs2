package ru.Kashapov.SpringBootBak2024.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.Kashapov.SpringBootBak2024.model.Request;

@Service
public interface ModifyRequestService {
    void modify(Request request, HttpHeaders headers);
}
