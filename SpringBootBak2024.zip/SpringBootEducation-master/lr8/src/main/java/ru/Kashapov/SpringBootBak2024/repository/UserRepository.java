package ru.Kashapov.SpringBootBak2024.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.Kashapov.SpringBootBak2024.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}