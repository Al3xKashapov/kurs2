package ru.Kashapov.SpringBootBak2024.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.Kashapov.SpringBootBak2024.entity.Discipline;

public interface DisciplineRepository extends JpaRepository<Discipline, Integer> {
}
